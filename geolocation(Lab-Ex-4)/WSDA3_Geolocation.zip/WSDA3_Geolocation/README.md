# WSDA3_Geolocation
representation of geolocation using bing map
